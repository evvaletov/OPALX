#!/usr/bin/env python3
"""Collect the saved outputs into one table (bend between its nominal faces).

OPALX maps were computed for drift(1 m) + bend + drift(1 m); the drifts are
removed here: M_bend = D(-1) M D(-1). Sources are the files named per row.
"""
import math
import pathlib
import re

import numpy as np

HERE = pathlib.Path(__file__).parent
H, L, LD = 0.5, 2.0 * math.pi / 6.0, 1.0
K_ENGE, I_IN = 0.3694584830, 0.2742292902  # analytic/analytic_edge.out


def opalx(name):
    lines = (HERE / "opalx" / name / f"{name}.out").read_text().splitlines()
    i = next(k for k, s in enumerate(lines) if "Combined linear transfer map" in s)
    m = np.array([[float(v) for v in lines[i + 1 + r].replace("OPAL-X>", "").split()] for r in range(6)])
    dinv = np.array([[1.0, -LD], [0.0, 1.0]])
    return dinv @ m[0:2, 0:2] @ dinv, dinv @ m[2:4, 2:4] @ dinv


def cosy():
    out, cur = {}, None
    for s in (HERE / "cosy" / "sbend_fringe.out").read_text().splitlines():
        if s.startswith("FR "):
            cur = s.strip()
            out[cur] = {}
        for key, val in re.findall(r"\((\w\|\w)\)=\s*([-+0-9.E]+)", s):
            out[cur][key] = float(val)
    return out


def madx(fname):
    for s in (HERE / "madx" / fname).read_text().splitlines():
        if s.lstrip().startswith('"B'):
            v = [float(t) for t in s.split()[1:]]
            return np.array([[v[1], v[2]], [v[3], v[4]]]), np.array([[v[7], v[8]], [v[9], v[10]]])


def thin(psi):
    k = H * math.tan(psi)
    return np.array([[1 + k * L, L], [2 * k + k * k * L, 1 + k * L]])


def row(label, hm, vm):
    k = (vm[1, 0] and (-1 + math.sqrt(1 + vm[1, 0] * L)) / L)  # 2k + k^2 L = R43
    print(f"{label:<58s} R21={hm[1,0]:+.9f} R33={vm[0,0]:.9f} R34={vm[0,1]:.9f} "
          f"R43={vm[1,0]:+.6e} R44={vm[1,1]:.9f} k_y/edge={k:+.6e} g*K_eff={math.atan(k/H)/H:.5f} m")


HB = np.array([[math.cos(L * H), math.sin(L * H) / H], [-H * math.sin(L * H), math.cos(L * H)]])
c = cosy()
cm = lambda d: (np.array([[d["x|x"], d["x|a"]], [d["a|x"], d["a|a"]]]), np.array([[d["y|y"], d["y|b"]], [d["b|y"], d["b|b"]]]))
print("rho=2 m, theta=pi/6, E1=E2=0. k_y/edge solves 2k + k^2 L = R43; g*K_eff = atan(k/h)/h in metres.")
print("== hard edge")
row("analytic", HB, thin(0.0))
row("MAD-X twiss_hardedge.tfs", *madx("twiss_hardedge.tfs"))
row("COSY INFINITY FR 0", *cm(c["FR 0 hard edge, d=0.1"]))
row("OPALX hardedge (HGAP=0)", *opalx("hardedge"))
print("== case A: HGAP=0.1 m (g=0.2 m), FINT=0.1")
row("analytic thin edge, psi=h*2*HGAP*FINT", HB, thin(H * 0.2 * 0.1))
row("MAD-X twiss_caseA_hgap0.1_fint0.1.tfs", *madx("twiss_caseA_hgap0.1_fint0.1.tfs"))
row("analytic thin edge, psi=h*HGAP*FINT", HB, thin(H * 0.1 * 0.1))
row("analytic thin edge, psi=h*g*K_Enge", HB, thin(H * 0.2 * K_ENGE))
row("MAD-X twiss_caseA_fint_eq_Kenge.tfs", *madx("twiss_caseA_fint_eq_Kenge.tfs"))
row("COSY INFINITY FR 3 (Enge, d=0.1)", *cm(c["FR 3 Enge fringe, d=0.1 (case A geometry)"]))
row("OPALX A-fint0 (HGAP=0.1, FINT=0)", *opalx("A-fint0"))
row("OPALX A-fint0p1 (HGAP=0.1, FINT=0.1)", *opalx("A-fint0p1"))
row("OPALX A-fint0p1-dthalf (same, DT/2)", *opalx("A-fint0p1-dthalf"))
print("== case B: HGAP=0.01 m (g=0.02 m), FINT=0.5")
row("analytic thin edge, psi=h*2*HGAP*FINT", HB, thin(H * 0.02 * 0.5))
row("MAD-X twiss_caseB_hgap0.01_fint0.5.tfs", *madx("twiss_caseB_hgap0.01_fint0.5.tfs"))
row("analytic thin edge, psi=h*HGAP*FINT", HB, thin(H * 0.01 * 0.5))
row("analytic thin edge, psi=h*g*K_Enge", HB, thin(H * 0.02 * K_ENGE))
row("COSY INFINITY FR 3 (Enge, d=0.01)", *cm(c["FR 3 Enge fringe, d=0.01 (case B geometry)"]))
row("OPALX B-fint0 (HGAP=0.01, FINT=0)", *opalx("B-fint0"))
row("OPALX B-fint0p5 (HGAP=0.01, FINT=0.5)", *opalx("B-fint0p5"))
print("== OPALX FINT increment per edge, R43: (FINT run - FINT=0 run)/2")
for a, b, g, f in (("A-fint0p1", "A-fint0", 0.2, 0.1), ("B-fint0p5", "B-fint0", 0.02, 0.5)):
    d = (opalx(a)[1][1, 0] - opalx(b)[1][1, 0]) / 2
    print(f"{a} - {b}: {d:.6e} 1/m; h*tan(h*HGAP*FINT)={H*math.tan(H*g/2*f):.6e}; h*tan(h*2*HGAP*FINT)={H*math.tan(H*g*f):.6e}")
    ky = [(-1 + math.sqrt(1 + opalx(n)[1][1, 0] * L)) / L for n in (a, b)]
    print(f"  R43 difference={2*d:.6e} 1/m; k_y/edge difference={ky[0]-ky[1]:.6e} 1/m; "
          f"K_eff=atan(k/h)/(h g): {math.atan(ky[1]/H)/H/g:.4f} (FINT=0), {math.atan(ky[0]/H)/H/g:.4f} (FINT={f})")
print("== first-order estimate for radial iso-field lines inside the body: k = h^2 g I_in, I_in = Int_inside (1-F) du")
for name, g in (("A-fint0", 0.2), ("B-fint0", 0.02)):
    hm, vm = opalx(name)
    kx = (-1.732050807568877 + math.sqrt(3.0 + 4.0 * (hm[1, 0] + 0.25))) / 2.0  # R21 = -h sin + 2 k cos + k^2 sin/h
    ky = (-1 + math.sqrt(1 + vm[1, 0] * L)) / L
    print(f"{name}: h^2 g I_in={H*H*g*I_IN:.6e}; OPALX horizontal k_x/edge={kx:.6e}; "
          f"h^2 g (K-I_in)={H*H*g*(K_ENGE-I_IN):.6e}; OPALX vertical k_y/edge={ky:.6e}")
print("== independent integration of the field model read from the OPALX source (analytic/track_field_model.out)")
print((HERE / "analytic" / "track_field_model.out").read_text().rstrip())
