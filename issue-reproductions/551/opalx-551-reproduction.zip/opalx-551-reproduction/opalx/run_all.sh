#!/bin/bash
# Run every case with one MPI rank and one OpenMP thread; keep stdout.
set -euo pipefail
export OMP_NUM_THREADS=1 OMP_PROC_BIND=false
OPALX=${OPALX_EXE_PATH:?}/opalx
cd "$(dirname "$0")"
for d in */; do
  n=${d%/}
  [ -f "$n/$n.in" ] || continue
  (cd "$n" && mpirun -np 1 "$OPALX" "$n.in" --info 2 </dev/null > "$n.out" 2>&1)
  echo "$n completed"
done
