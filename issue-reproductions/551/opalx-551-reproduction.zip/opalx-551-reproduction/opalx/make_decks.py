#!/usr/bin/env python3
"""Write OPALX decks: 1 m drift, 30 degree SBEND (rho = 2 m), 1 m drift.

Same beam, bend geometry and linear-map options as lin-map-3/lin-map-6 of
OPALX PR 550; the drifts hold the +-5 g Enge support for HGAP = 0.1 m.
"""
import math
import pathlib

RHO, THETA, LD = 2.0, math.pi / 6.0, 1.0
LB = RHO * THETA
TEMPLATE = """// {name}: drift, 30 degree sector bend (HGAP={hgap}, FINT={fint}), drift.
OPTION, ECHO=FALSE, PSDUMPFREQ=0, STATDUMPFREQ=1, ASCIIDUMP=FALSE;
OPTION, ENABLELINEARTRANSFERMAPS=TRUE,
 LINEARTRANSFERMAPINTEGRATOR="DOP853", LINEARTRANSFERMAPRICHARDSON=1,
 LINEARTRANSFERMAPSTEPS={{0.0001,0.0001,0.0001,0.0001,0.0001,0.0001}};
REAL P0=0.25051047777488272;
D0: DRIFT, L={ld!r}, APERTURE="RECTANGLE(1.0,0.2)", X=0, Y=0, Z=0, THETA=-0, PHI=0, PSI=0;
B: SBEND, L={lb!r}, ANGLE={theta!r}, HGAP={hgap}, FINT={fint}, X=0, Y=0, Z={ld!r}, THETA=-0, PHI=0, PSI=0;
D1: DRIFT, L={ld!r}, APERTURE="RECTANGLE(1.0,0.2)", X={x1!r}, Y=0, Z={z1!r}, THETA={th1!r}, PHI=0, PSI=0;
LATTICE: LINE = (D0,B,D1);
DIST: DISTRIBUTION, TYPE=FROMFILE, FNAME="reference-particle.txt", NPARTDIST=1;
SOURCE: EMISSIONSOURCE, DISTRIBUTION=DIST;
SOURCES: EMISSIONSOURCELIST=(SOURCE);
FS: FIELDSOLVER, TYPE=NONE, NX=16, NY=16, NZ=16,
 PARFFTX=TRUE, PARFFTY=TRUE, PARFFTZ=TRUE, BCFFTX=OPEN, BCFFTY=OPEN, BCFFTZ=OPEN,
 BBOXINCR=1, GREENSF=INTEGRATED;
BEAM1: BEAM, PARTICLE=ELECTRON, NALLOC=1, BCHARGE=1.602176634e-19, SOURCES=SOURCES, CHARGE=-1;
TRACK, LINE=LATTICE, BEAM=BEAM1, MAXSTEPS=1, DT={dt}, ZSTOP={zstop!r};
RUN, METHOD="PARALLEL", FIELDSOLVER=FS;
ENDTRACK;
QUIT;
"""
CASES = [
    ("hardedge", 0, 0, 1e-11),
    ("A-fint0p1", 0.1, 0.1, 1e-11),
    ("A-fint0p1-dthalf", 0.1, 0.1, 5e-12),
    ("A-fint0", 0.1, 0, 1e-11),
    ("B-fint0p5", 0.01, 0.5, 2e-12),
    ("B-fint0", 0.01, 0, 2e-12),
]
for name, hgap, fint, dt in CASES:
    d = pathlib.Path(name)
    d.mkdir(exist_ok=True)
    (d / f"{name}.in").write_text(TEMPLATE.format(
        name=name, hgap=hgap, fint=fint, dt=dt, ld=LD, lb=LB, theta=THETA,
        x1=-RHO * (1.0 - math.cos(THETA)), z1=LD + RHO * math.sin(THETA),
        th1=-THETA, zstop=2.0 * LD + LB))
    (d / "reference-particle.txt").write_text("1\nx px y py z pz\n0 0 0 0 0 490.23677597553325\n")
