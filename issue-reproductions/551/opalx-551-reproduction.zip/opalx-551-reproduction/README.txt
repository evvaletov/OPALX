OPALX issue 551: SBEND fringe comparison

Reproduction files for:
https://github.com/OPALX-project/OPALX/issues/551#issuecomment-7063673086

The main case is a 30-degree sector bend with radius 2 m, E1 = E2 = 0
and HGAP = 0.1 m, between two 1 m drifts. A-fint0 and A-fint0p1 are
the two OPALX rows in the comment. hardedge, the smaller-gap B cases
and A-fint0p1-dthalf provide additional comparisons.

Saved results and provenance

The .out, .log and .tfs files are saved results from the original runs.
Their numerical content is unchanged. The local executable path in the
OPALX .out files has been replaced by <OPALX_EXECUTABLE>.
Work on a copy before rerunning any program or deck, including MAD-X,
to retain the archived results. The MAD-X deck replaces its four .tfs files.
Use sha256sum -c SHA256SUMS to check the archive before any reruns.

OPALX revision: c20fbbdce74d4b1c92f8ad32f1955a7950d47f17
Build: Release, PLATFORMS=OPENMP, GCC 16.2.1, Open MPI 5.0.11,
CMake 4.4.3; runs used one MPI rank and one OpenMP thread.
Reference programs: MAD-X 5.04.01 and COSY INFINITY 10.2.
Rechecked on 22 November 2026: rerunning all six OPALX cases gave a
comparison table byte-identical to comparison_table.txt. Both Python
scripts reproduced their saved output byte for byte. MAD-X and COSY
INFINITY were not rerun. Software versions for the recheck: Python
3.14.10, NumPy 2.5.5 and SciPy 1.17.1.
The OPALX decks use an electron; the MAD-X and COSY INFINITY decks
use a proton. All use approximately 0.25051 GeV/c momentum; the COSY
INFINITY deck specifies a kinetic energy of 32.867 MeV.

No change to OPALX is included. The Python tracker is a separate
implementation of the field model at that revision. Its arc mode uses
the design arc-length coordinate inside the bend. Its perp mode uses
the distance normal to the nearer pole face and the corresponding
face-based axes. Switching from arc to perp changes the field axes
as well as the profile argument.

Table rows and source files

- OPALX rows: opalx/<case>/<case>.in and the matching .out file,
  with reference-particle.txt in the same directory. The six case names
  are hardedge, A-fint0, A-fint0p1, A-fint0p1-dthalf, B-fint0 and B-fint0p5.
- MAD-X rows: madx/sbend_fint.madx writes the four .tfs files named in
  the row labels. madx/sbend_fint.log is the saved console output.
- COSY INFINITY rows: cosy/sbend_fringe.fox and cosy/sbend_fringe.out,
  with blocks labelled FR 0, FR 3 with d=0.1, and FR 3 with d=0.01.
  A fourth block, FR 3 with d=0.001, is saved but not used in the table.
- Analytic hard-edge and thin-edge rows: the HB and thin() calculations
  in compare.py. The full-gap and half-gap checks and the Enge integrals
  are also printed by analytic/analytic_edge.py and saved in
  analytic/analytic_edge.out.
- FINT increment rows: compare.py subtracts the named OPALX case maps.
- First-order estimates: compare.py combines the A-fint0/B-fint0 maps
  with K_ENGE and I_IN constants copied from analytic/analytic_edge.out.
- Arc/perp tracking rows: analytic/track_field_model.py and its saved
  track_field_model.out; compare.py appends that output verbatim.

Quick check using saved outputs

Use Python 3 with NumPy and SciPy installed. From this directory:

  python3 compare.py > comparison-rerun.txt
  diff -u comparison_table.txt comparison-rerun.txt

compare.py extracts the OPALX maps and removes the two 1 m drifts via
D(-1) M D(-1). R21 and R43 are unchanged by this removal. It reads the
saved MAD-X and COSY INFINITY outputs and includes the saved Python
tracking results at the end. This command does not run the integrators.

Rerun the analytic and geometry comparisons

  python3 analytic/analytic_edge.py > analytic/analytic_edge.rerun.txt
  python3 analytic/track_field_model.py > analytic/track_field_model.rerun.txt

These commands leave the saved .out files intact. Compare the rerun files
with the corresponding .out files:

  diff -u analytic/analytic_edge.out analytic/analytic_edge.rerun.txt
  diff -u analytic/track_field_model.out analytic/track_field_model.rerun.txt

The tracker uses SciPy DOP853 with rtol=1e-13, atol=1e-15, maximum
step g/20 and central differences of 1e-5, where g = 2 HGAP. It prints both arc and perp cases. The A-case
R21 and R43 values in arc mode reproduce the OPALX values to about six
significant figures. For A-fint0, the tracker gives R34 = 1.044876475 m
and R33 = 1.004957059; OPALX gives 1.047079466 m and 1.004979022,
respectively. Agreement for the full matrix has not been established.

Rerun OPALX

Build the pinned revision using the upstream build instructions. Make
mpirun available, and set OPALX_EXE_PATH to the absolute directory
containing the opalx executable. On the working copy, run_all.sh replaces
each case's .out file.

  export OPALX_EXE_PATH=/absolute/path/to/directory-containing-opalx
  bash opalx/run_all.sh
  python3 compare.py > comparison-rerun.txt
  diff -u comparison_table.txt comparison-rerun.txt

The runner was updated to stop at the first failed case and prevent
mpirun from reading the caller's standard input. Scientific scripts
and decks are unchanged.

The input decks and reference particles are included. To regenerate those inputs, run make_decks.py
from the opalx directory; it writes relative to the working directory:

  cd opalx
  python3 make_decks.py

The beam and linear-map options derive from the lin-map-3/lin-map-6
examples attached to OPALX PR 550. A-fint0p1-dthalf halves TRACK.DT;
the linear-map options are unchanged.

Additional reference decks

madx/sbend_fint.madx can be run with MAD-X from its own directory.
cosy/sbend_fringe.fox uses a separately installed COSY INFINITY 10.2
runtime and expects the compiled COSY library at cosy/build/COSY.bin.
That runtime and library are not distributed in this bundle. The saved
outputs allow the table to be reconstructed without either program.

The comparison is evidence for deciding the FINT and geometry conventions.
It does not prescribe which convention OPALX should adopt.
