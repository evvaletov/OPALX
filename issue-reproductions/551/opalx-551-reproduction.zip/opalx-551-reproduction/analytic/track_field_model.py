#!/usr/bin/env python3
"""Independent integration of the bend field model read from the OPALX source.

Field of BendFieldModel::bendField (BendFieldModel.h:180-213) with the chart of
GeometryHelper::toBendArcCoords (Geometry.h:181-207) and the support of
SBend::getFieldExtent (+-5 g): straight coordinates outside the faces, radial
offset and design arc length inside the body. Units: B0 = 1, so every ray obeys
du/dl = h (u x b).

"arc"  : the profile argument inside the body is the design arc length (OPALX).
"perp" : the profile argument is the distance perpendicular to the nearer face.

Rays start 1 m before the entrance face and stop 1 m behind the exit face; the
first-order blocks follow from central differences and the drifts are removed.
g is the full gap, 2 HGAP. Case A (g = 0.2 m) is the dipole of OPALX issue 551;
case B (g = 0.02 m) is a small-gap cross-check.
"""
import math

import numpy as np
from scipy.integrate import solve_ivp

RHO, THETA, LD = 2.0, math.pi / 6.0, 1.0
H, LB = 1.0 / RHO, RHO * THETA
C = (0.478959, 1.911289, -1.185953, 1.630554, -1.082657, 0.318111)
CE, SE = math.cos(THETA), math.sin(THETA)
EXIT = np.array([(CE - 1.0) / H, 0.0, SE / H])


def enge(d, g):
    u = d / g
    p = sum(c * u**i for i, c in enumerate(C))
    if p > 80.0:
        return 0.0, 0.0, 0.0
    if p < -80.0:
        return 1.0, 0.0, 0.0
    p1 = sum(i * c * u ** (i - 1) for i, c in enumerate(C) if i) / g
    p2 = sum(i * (i - 1) * c * u ** (i - 2) for i, c in enumerate(C) if i > 1) / g**2
    e = math.exp(p)
    f = 1.0 / (1.0 + e)
    return f, -p1 * e * f * f, -(p2 + p1 * p1) * e * f * f + 2.0 * (p1 * e) ** 2 * f**3


def field(r, g, coef, mode):
    """b = B/B0 in the entrance frame; coef = Delta k_y / (h * span)."""
    x, y, z = r
    dx, dz = x - EXIT[0], z - EXIT[2]
    zexit = -SE * dx + CE * dz
    # ex, es: local transverse and longitudinal unit vectors as (x, z) pairs; "perp" takes those
    # of the nearer face, set below. Bend centre at x = -RHO, so the design arc bends towards -x.
    if mode == "arc":
        if z <= 0.0:
            s, ex, es = z, (1.0, 0.0), (0.0, 1.0)
        elif zexit >= 0.0:
            s, ex, es = LB + zexit, (CE, SE), (-SE, CE)
        else:
            phi = math.atan2(z, x + RHO)
            s, ex, es = phi * RHO, (math.cos(phi), math.sin(phi)), (-math.sin(phi), math.cos(phi))
        d_in, d_out = -s, s - LB
    else:
        d_in, d_out = -z, zexit
    # Support: closed at the entrance end, open at the exit end (SBend::isInsideArc in arc mode).
    if d_in > 5.0 * g or d_out >= 5.0 * g:
        return np.zeros(3)
    fi, fo = enge(d_in, g), enge(d_out, g)
    if fo[0] < fi[0]:
        f, f1, f2, face = fo[0], fo[1], fo[2], 1
    else:
        f, f1, f2, face = fi[0], -fi[1], fi[2], 0
    if mode == "perp":
        ex, es = ((1.0, 0.0), (0.0, 1.0)) if face == 0 else ((CE, SE), (-SE, CE))
    bx = (coef if face == 0 else -coef) * f1 * y
    by = f - 0.5 * f2 * y * y
    bs = f1 * y
    return np.array([bx * ex[0] + bs * es[0], by, bx * ex[1] + bs * es[1]])


def rhs(_, w, g, coef, mode):
    r, u = w[:3], w[3:]
    b = field(r, g, coef, mode)
    return np.concatenate([u, H * np.cross(u, b)])


def ray(x, xp, y, yp, g, coef, mode):
    u = np.array([xp, yp, 1.0])
    u /= np.linalg.norm(u)
    w0 = np.concatenate([[x, y, -LD], u])

    def stop(_, w, *a):
        return -SE * (w[0] - EXIT[0]) + CE * (w[2] - EXIT[2]) - LD

    stop.terminal, stop.direction = True, 1.0
    sol = solve_ivp(rhs, (0.0, 10.0), w0, method="DOP853", rtol=1e-13, atol=1e-15,
                    max_step=g / 20.0, events=stop, args=(g, coef, mode))
    w = sol.y_events[0][0]
    dx, dz = w[0] - EXIT[0], w[2] - EXIT[2]
    xl = CE * dx + SE * dz
    ux, uz = CE * w[3] + SE * w[5], -SE * w[3] + CE * w[5]
    return np.array([xl, ux / uz, w[1], w[4] / uz]), sol.t_events[0][0]


def blocks(g, fint, mode, eps=1e-5):
    span = abs(enge(-5.0 * g, g)[0] - enge(5.0 * g, g)[0])
    coef = math.tan(0.5 * H * g * fint) / span  # Delta k_y / (h span), half-gap psi, E = 0; span = 1 here
    m = np.zeros((4, 4))
    for j in range(4):
        d = np.zeros(4)
        d[j] = eps
        m[:, j] = (ray(*d, g, coef, mode)[0] - ray(*-d, g, coef, mode)[0]) / (2.0 * eps)
    dinv = np.array([[1.0, -LD], [0.0, 1.0]])
    return dinv @ m[0:2, 0:2] @ dinv, dinv @ m[2:4, 2:4] @ dinv, ray(0.0, 0.0, 0.0, 0.0, g, coef, mode)


if __name__ == "__main__":
    print("Bend between nominal faces (1 m drifts removed); rho=2 m, theta=pi/6, E1=E2=0.")
    print("mode arc = OPALX chart (design arc length inside the body); perp = distance normal to the face.")
    print(f"ref: reference ray at the end plane, 1 m behind the exit face; path = its length minus the design {2.0 * LD + LB:.9f} m.")
    for mode, label, g, fint in (
            ("arc", "A g=0.2 FINT=0", 0.2, 0.0),
            ("arc", "A g=0.2 FINT=0.1 (half-gap psi)", 0.2, 0.1),
            ("arc", "B g=0.02 FINT=0", 0.02, 0.0),
            ("arc", "B g=0.02 FINT=0.5 (half-gap psi)", 0.02, 0.5),
            ("perp", "A g=0.2 FINT=0", 0.2, 0.0),
            ("perp", "B g=0.02 FINT=0", 0.02, 0.0)):
        hm, vm, (ref, path) = blocks(g, fint, mode)
        print(f"{mode:4s} {label:34s} R21={hm[1,0]:+.9f} R33={vm[0,0]:.9f} R34={vm[0,1]:.9f} "
              f"R43={vm[1,0]:+.6e} R44={vm[1,1]:.9f} ref x={ref[0]:+.3e} m x'={ref[1]:+.3e} "
              f"path={path - 2.0 * LD - LB:+.3e} m", flush=True)
