#!/usr/bin/env python3
"""Hard-edge sector bend with thin FINT edges: vertical first-order block.

Edge (MAD-X / CAS / SLAC-75 convention, full gap g = 2*HGAP):
    psi = h * g * FINT * (1 + sin^2 E) / cos E,   R43 = -h * tan(E - psi)
Body of a sector bend without gradient: vertical drift of length L = rho*theta.

Also evaluates the fringe integral K = (1/g) * Int F (1 - F) ds of the Enge
profile hard-coded in OPALX src/AbsBeamline/BendFieldModel.h (lines 58-63),
and the offset of its effective field boundary from the nominal face.
"""
import math
from scipy.integrate import quad

RHO, THETA = 2.0, math.pi / 6.0
H, L = 1.0 / RHO, RHO * THETA
C = (0.478959, 1.911289, -1.185953, 1.630554, -1.082657, 0.318111)


def enge(u):
    p = sum(c * u**i for i, c in enumerate(C))
    if p > 80.0:
        return 0.0
    if p < -80.0:
        return 1.0
    return 1.0 / (1.0 + math.exp(p))


def vertical_block(psi, e=0.0):
    k = -H * math.tan(e - psi)
    return k, ((1.0 + k * L, L), (2.0 * k + k * k * L, 1.0 + k * L))


def report(label, hgap, fint):
    print(f"--- {label}: rho={RHO} m, theta=pi/6, L={L:.16g} m, HGAP={hgap} m, FINT={fint}, E1=E2=0")
    for name, gap in (("full gap g=2*HGAP (MAD-X/CAS)", 2.0 * hgap), ("half gap g=HGAP (OPALX helper)", hgap)):
        psi = H * gap * fint
        k, m = vertical_block(psi)
        print(f"  {name}: psi={psi:.12g} rad  k_y=R43(edge)={k:.12e} 1/m")
        print(f"    R33={m[0][0]:.12f} R34={m[0][1]:.12f} R43={m[1][0]:.12e} R44={m[1][1]:.12f}")


for a in (5.0, 10.0, 40.0):
    K = quad(lambda u: enge(u) * (1.0 - enge(u)), -a, a, limit=400, epsabs=1e-14, epsrel=1e-13)[0]
    inside = quad(lambda u: 1.0 - enge(u), -a, 0.0, limit=400, epsabs=1e-14)[0]
    outside = quad(enge, 0.0, a, limit=400, epsabs=1e-14)[0]
    print(f"Enge profile, |u|<={a:g} full gaps: K=Int F(1-F) du = {K:.10f}; "
          f"Int_out F du = {outside:.10f}; Int_in (1-F) du = {inside:.10f}; "
          f"EFB offset (out - in) = {outside - inside:+.3e} full gaps")
print(f"F(0) = {enge(0.0):.8f}")
report("case A (issue #551 values)", 0.1, 0.1)
report("case B (small gap)", 0.01, 0.5)
K = quad(lambda u: enge(u) * (1.0 - enge(u)), -5, 5, limit=400)[0]
for label, hgap in (("case A", 0.1), ("case B", 0.01)):
    psi = H * 2.0 * hgap * K
    k, m = vertical_block(psi)
    print(f"--- {label}, thin edge with FINT := K_Enge = {K:.10f}, full gap: psi={psi:.12g} rad k_y={k:.12e} 1/m")
    print(f"    R33={m[0][0]:.12f} R34={m[0][1]:.12f} R43={m[1][0]:.12e} R44={m[1][1]:.12f}")
